-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 17, 2024 at 11:17 AM
-- Server version: 8.0.36-cll-lve
-- PHP Version: 8.1.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

-- Sections: Base Table Creation, Key Creation, Auto Increment Setting, Constraint Setting, Data Setting, Permissions

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `zltbjcro_reckrds`
--

--
-- <Base Table Creation> --------------------------------------------------------
--

-- Prebuilt tables

CREATE TABLE `campuses` (
  `campusid` tinyint AUTO_INCREMENT,
  `campusname` varchar(64) COLLATE utf8mb3_unicode_ci NOT NULL,
  `shortname` varchar(32) COLLATE utf8mb3_unicode_ci NOT NULL,
  `domain` varchar(32) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `insertedby` int DEFAULT NULL,
  `insertedon` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  
  PRIMARY KEY (`campusid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci COMMENT='Campuses';

ALTER TABLE `campuses` AUTO_INCREMENT=17;

CREATE TABLE `cohorts` (
  `cohortid` int NOT NULL AUTO_INCREMENT,
  `title` varchar(32) COLLATE utf8mb3_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb3_unicode_ci NOT NULL,
  `isactive` tinyint(1) NOT NULL DEFAULT '1',
  `insertedby` int DEFAULT NULL,
  `insertedon` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  
  PRIMARY KEY (`cohortid`),
  KEY `insertedby` (`insertedby`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci COMMENT='Student cohorts';

CREATE TABLE `cohortstudents` (
  `cohortstudentid` int NOT NULL AUTO_INCREMENT,
  `cohortid` int NOT NULL,
  `studentid` int NOT NULL,
  `insertedby` int DEFAULT NULL,
  `insertedon` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  
  PRIMARY KEY (`cohortstudentid`),
  KEY `cohortid` (`cohortid`),
  KEY `studentid` (`studentid`),
  KEY `insertedby` (`insertedby`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci COMMENT='Students in student cohorts';

CREATE TABLE `employees` (
  `employeeid` int NOT NULL AUTO_INCREMENT,
  `idnumber` varchar(12) COLLATE utf8mb3_unicode_ci NOT NULL,
  `uuid` binary(16) DEFAULT NULL,
  `userid` int DEFAULT NULL,
  `insertedby` int DEFAULT NULL,
  `insertedon` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  
  PRIMARY KEY (`employeeid`),
  KEY `userid` (`userid`),
  KEY `insertedby` (`insertedby`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci COMMENT='Employees';

CREATE TABLE `extensions` (
  `extensionid` varchar(4) COLLATE utf8mb3_unicode_ci NOT NULL,
  `extension` varchar(8) COLLATE utf8mb3_unicode_ci NOT NULL,
  `ordinal` tinyint NOT NULL,
  `insertedby` int DEFAULT NULL,
  `insertedon` datetime DEFAULT CURRENT_TIMESTAMP,
  
  PRIMARY KEY (`extensionid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci COMMENT='Name extensions';

CREATE TABLE `persons` (
  `personid` int NOT NULL AUTO_INCREMENT,
  `familyname` varchar(32) COLLATE utf8mb3_unicode_ci NOT NULL,
  `givenname` varchar(64) COLLATE utf8mb3_unicode_ci NOT NULL,
  `middlename` varchar(32) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `fullname` varchar(255) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `livedname` varchar(64) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `fulllivedname` varchar(255) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `bdate` date DEFAULT NULL,
  `midinit` varchar(12) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `extensionid` varchar(4) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `userid` int DEFAULT NULL,
  `insertedby` int DEFAULT NULL,
  `insertedon` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  
  PRIMARY KEY (`personid`),
  KEY `familyname` (`familyname`),
  KEY `givenname` (`givenname`),
  KEY `fullname` (`fullname`),
  KEY `insertedby` (`insertedby`),
  KEY `extensionid` (`extensionid`),
  KEY `userid` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci COMMENT='Persons';

CREATE TABLE `sections` (
  `sectionid` int NOT NULL AUTO_INCREMENT,
  `name` varchar(32) COLLATE utf8mb3_unicode_ci NOT NULL,
  `acadyear` smallint NOT NULL,
  `campusid` tinyint NOT NULL,
  `level` tinyint NOT NULL,
  `isactive` tinyint(1) NOT NULL DEFAULT '1',
  `insertedby` int DEFAULT NULL,
  `insertedon` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  
  PRIMARY KEY (`sectionid`),
  KEY `sections_ibfk_1` (`campusid`),
  KEY `sections_ibfk_2` (`insertedby`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci COMMENT='Sections';

CREATE TABLE `students` (
  `studentid` int NOT NULL AUTO_INCREMENT,
  `idnumber` varchar(24) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `uuid` binary(16) NOT NULL,
  `lrn` varchar(16) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `personid` int NOT NULL,
  `campusid` int NOT NULL,
  `isactive` tinyint NOT NULL DEFAULT '1',
  `insertedby` int DEFAULT NULL,
  `insertedon` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  
  PRIMARY KEY (`studentid`),
  KEY `idnumber` (`idnumber`),
  KEY `personid` (`personid`),
  KEY `insertedby` (`insertedby`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;

CREATE TABLE `users` (
  `userid` int NOT NULL AUTO_INCREMENT,
  `uuid` binary(16) NOT NULL,
  `username` varchar(64) COLLATE utf8mb3_unicode_ci NOT NULL,
  `passwd` varchar(255) COLLATE utf8mb3_unicode_ci NOT NULL,
  `isactive` tinyint(1) NOT NULL DEFAULT '1',
  `insertedby` int DEFAULT NULL,
  `insertedon` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  
  PRIMARY KEY (`userid`),
  UNIQUE KEY `useruuid` (`uuid`),
  UNIQUE KEY `username` (`username`),
  KEY `insertedby` (`insertedby`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci COMMENT='Users';

-- Custom SCALE tables

CREATE TABLE `activities` (
  `activityid` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `prepstartdate` date DEFAULT NULL,
  `prependdate` date DEFAULT NULL,
  `implementstartdate` date DEFAULT NULL,
  `implementenddate` date DEFAULT NULL,
  `venue` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `objectives` text DEFAULT NULL,
  `approved` boolean DEFAULT FALSE,
  `approvaldate` datetime DEFAULT NULL,
  `isactive` BOOLEAN DEFAULT TRUE,
  `insertedby` int DEFAULT NULL,
  `insertedon` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  
  PRIMARY KEY (`activityid`),
  KEY `insertedby` (`insertedby`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci COMMENT='SCALE Activities';

CREATE TABLE `activitystudents` (
  `activitystudentid` int not null AUTO_INCREMENT,
  `studentid` int NOT NULL,
  `activityid` int NOT NULL,
  `position` varchar(64) COLLATE utf8mb3_unicode_ci NOT NULL,
  `status` varchar(16) COLLATE utf8mb3_unicode_ci NOT NULL,
  `isactive` BOOLEAN DEFAULT TRUE,
  `insertedby` int DEFAULT NULL,
  `insertedon` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  
  PRIMARY KEY (`activitystudentid`),
  KEY `studentid` (`studentid`),
  KEY `activityid` (`activityid`),
  KEY `insertedby` (`insertedby`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci COMMENT='Student positions in a SCALE activity';

CREATE TABLE `adultsupervisors` (
  `supervisorid` int NOT NULL AUTO_INCREMENT,
  `personid` int NOT NULL,
  `activityid` int NOT NULL,
  `isactive` BOOLEAN DEFAULT TRUE,
  `insertedby` int DEFAULT NULL,
  `insertedon` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  
  PRIMARY KEY (`supervisorid`),
  KEY `personid` (`personid`),
  KEY `activityid` (`activityid`),
  KEY `insertedby` (`insertedby`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci COMMENT='SCALE Adult Supervisors';

CREATE TABLE `coordinators` (
  `coordinatorid` int NOT NULL AUTO_INCREMENT,
  `employeeid` int NOT NULL,
  `acadyear` smallint NOT NULL,
  `isactive` BOOLEAN DEFAULT TRUE,
  `insertedby` int DEFAULT NULL,
  `insertedon` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  
  PRIMARY KEY (`coordinatorid`),
  KEY `employeeid` (`employeeid`),
  KEY `insertedby` (`insertedby`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci COMMENT='SCALE Coordinators';

CREATE TABLE `materials` (
  `materialid` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `quantity` int DEFAULT 0,
  `cost` decimal(8,2) DEFAULT 0,
  `activityid` int DEFAULT NULL,
  `isactive` BOOLEAN DEFAULT TRUE,
  `insertedby` int DEFAULT NULL,
  `insertedon` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  
  PRIMARY KEY (`materialid`),
  KEY `activiyid` (`activityid`),
  KEY `insertedby` (`insertedby`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci COMMENT='SCALE Acitvity Materials';

CREATE TABLE `scaleadvisors` (
  `scaleadvisorid` int NOT NULL AUTO_INCREMENT,
  `employeeid` int NOT NULL,
  `studentid` int NOT NULL,
  `isactive` BOOLEAN DEFAULT TRUE,
  `insertedby` int DEFAULT NULL,
  `insertedon` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  
  PRIMARY KEY (`scaleadvisorid`),
  KEY `employeeid` (`employeeid`),
  KEY `studentid` (`studentid`),
  KEY `insertedby` (`insertedby`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci COMMENT='SCALE Advisors';

CREATE TABLE `scalefaq` (
  `scalefaqid` int not null AUTO_INCREMENT,
  `question` varchar(255) COLLATE utf8mb3_unicode_ci NOT NULL,
  `questioncategory` varchar(32) COLLATE utf8mb3_unicode_ci NOT NULL,
  `answer` text DEFAULT NULL,
  `isactive` BOOLEAN DEFAULT TRUE,
  `insertedby` int DEFAULT NULL,
  `insertedon` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  
  PRIMARY KEY (`scalefaqid`),
  KEY `insertedby` (`insertedby`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci COMMENT='SCALE Frequently Asked Questions';

CREATE TABLE `scaleforms` (
  `scaleformid` int NOT NULL AUTO_INCREMENT,
  `formtitle` varchar(64) COLLATE utf8mb3_unicode_ci NOT NULL,
  `formdescription` varchar(511) COLLATE utf8mb3_unicode_ci NOT NULL,
  `versionnumber` varchar(64) COLLATE utf8mb3_unicode_ci NOT NULL,
  `isactive` tinyint(1) NOT NULL DEFAULT '1',
  `insertedby` int DEFAULT NULL,
  `insertedon` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  
  PRIMARY KEY (`scaleformid`),
  KEY `insertedby` (`insertedby`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci COMMENT='SCALE Forms';

CREATE TABLE `scalerequirements` (
  `scalerequirementid` int NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL,
  `description` varchar(512) NOT NULL,
  `shortname` varchar(32) NOT NULL,
  `isactive` BOOLEAN DEFAULT TRUE,
  `insertedby` int DEFAULT NULL,
  `insertedon` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  
  PRIMARY KEY (`scalerequirementid`),
  KEY `insertedby` (`insertedby`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci COMMENT='SCALE strands and learning outcomes';

CREATE TABLE `studentscalereqs` (
  `studentscalereqid` int not null AUTO_INCREMENT,
  `activitystudentid` int NOT NULL,
  `scalerequirementid` int NOT NULL,
  `approved` boolean DEFAULT FALSE,
  `approvaldate` datetime DEFAULT NULL,
  `completed` boolean DEFAULT FALSE,
  `completiondate` datetime DEFAULT NULL,
  `scaleadvisorid` int NOT NULL,
  `isactive` BOOLEAN DEFAULT TRUE,
  `insertedby` int DEFAULT NULL,
  `insertedon` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  
  PRIMARY KEY (`studentscalereqid`),
  KEY `activitystudentid` (`activitystudentid`),
  KEY `scalerequirementid` (`scalerequirementid`),
  KEY `scaleadvisorid` (`scaleadvisorid`),
  KEY `insertedby` (`insertedby`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci COMMENT='SCALE requirements taken by students';

CREATE TABLE `submissions` (
  `submissionid` int not null AUTO_INCREMENT,
  `submissiontype` varchar(32) COLLATE utf8mb3_unicode_ci NOT NULL,
  `studentid` int NOT NULL,
  `activityid` int NOT NULL,
  `textsubmission` text DEFAULT NULL,
  `linksubmission` varchar(1024) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `submissionstatus` varchar(64) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `isactive` BOOLEAN DEFAULT TRUE,
  `insertedby` int DEFAULT NULL,
  `insertedon` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  
  PRIMARY KEY (`submissionid`),
  KEY `studentid` (`studentid`),
  KEY `activityid` (`activityid`),
  KEY `insertedby` (`insertedby`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci COMMENT='Student SCALE submissions';

--
-- <Constraint Setting> --------------------------------------------------------
--

-- Prebuilt tables

ALTER TABLE `cohorts`
  ADD CONSTRAINT `cohorts_ibfk_1` FOREIGN KEY (`insertedby`) REFERENCES `users` (`userid`) ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE `cohortstudents`
  ADD CONSTRAINT `cohortstudents_ibfk_1` FOREIGN KEY (`cohortid`) REFERENCES `cohorts` (`cohortid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cohortstudents_ibfk_2` FOREIGN KEY (`studentid`) REFERENCES `students` (`studentid`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `cohortstudents_ibfk_3` FOREIGN KEY (`insertedby`) REFERENCES `users` (`userid`) ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE `employees`
  ADD CONSTRAINT `employees_ibfk_1` FOREIGN KEY (`userid`) REFERENCES `users` (`userid`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `employees_ibfk_2` FOREIGN KEY (`insertedby`) REFERENCES `users` (`userid`) ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE `persons`
  ADD CONSTRAINT `persons_ibfk_1` FOREIGN KEY (`insertedby`) REFERENCES `users` (`userid`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `persons_ibfk_2` FOREIGN KEY (`extensionid`) REFERENCES `extensions` (`extensionid`) ON UPDATE CASCADE,
  ADD CONSTRAINT `persons_ibfk_3` FOREIGN KEY (`userid`) REFERENCES `users` (`userid`) ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE `sections`
  ADD CONSTRAINT `sections_ibfk_1` FOREIGN KEY (`campusid`) REFERENCES `campuses` (`campusid`) ON UPDATE CASCADE,
  ADD CONSTRAINT `sections_ibfk_2` FOREIGN KEY (`insertedby`) REFERENCES `users` (`userid`) ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE `students`
  ADD CONSTRAINT `students_ibfk_1` FOREIGN KEY (`personid`) REFERENCES `persons` (`personid`) ON UPDATE CASCADE,
  ADD CONSTRAINT `students_ibfk_2` FOREIGN KEY (`insertedby`) REFERENCES `users` (`userid`) ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`insertedby`) REFERENCES `users` (`userid`) ON DELETE SET NULL ON UPDATE CASCADE;

-- Custom scale tables

ALTER TABLE `activities`
  ADD CONSTRAINT `activities_ibfk_2` FOREIGN KEY (`insertedby`) REFERENCES `users` (`userid`) ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE `activitystudents`
  ADD CONSTRAINT `activitystudents_ibfk_1` FOREIGN KEY (`studentid`) REFERENCES `students` (`studentid`) ON UPDATE CASCADE,
  ADD CONSTRAINT `activitystudents_ibfk_2` FOREIGN KEY (`activityid`) REFERENCES `activities` (`activityid`) ON UPDATE CASCADE,
  ADD CONSTRAINT `activitystudents_ibfk_3` FOREIGN KEY (`insertedby`) REFERENCES `users` (`userid`) ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE `adultsupervisors`
  ADD CONSTRAINT `adultsupervisors_ibfk_1` FOREIGN KEY (`personid`) REFERENCES `persons` (`personid`) ON UPDATE CASCADE,
  ADD CONSTRAINT `adultsupervisors_ibfk_2` FOREIGN KEY (`activityid`) REFERENCES `activities` (`activityid`) ON UPDATE CASCADE,
  ADD CONSTRAINT `adultsupervisors_ibfk_3` FOREIGN KEY (`insertedby`) REFERENCES `users` (`userid`) ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE `coordinators`
  ADD CONSTRAINT `coordinators_ibfk_1` FOREIGN KEY (`employeeid`) REFERENCES `employees` (`employeeid`)  ON UPDATE CASCADE,
  ADD CONSTRAINT `coordinators_ibfk_2` FOREIGN KEY (`insertedby`) REFERENCES `users` (`userid`) ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE `materials`
  ADD CONSTRAINT `materials_ibfk_1` FOREIGN KEY (`activityid`) REFERENCES `activities` (`activityid`)  ON UPDATE CASCADE,
  ADD CONSTRAINT `materials_ibfk_2` FOREIGN KEY (`insertedby`) REFERENCES `users` (`userid`) ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE `scaleadvisors`
  ADD CONSTRAINT `scaleadvisors_ibfk_1` FOREIGN KEY (`employeeid`) REFERENCES `employees` (`employeeid`)  ON UPDATE CASCADE,
  ADD CONSTRAINT `scaleadvisors_ibfk_2` FOREIGN KEY (`studentid`) REFERENCES `students` (`studentid`)  ON UPDATE CASCADE,
  ADD CONSTRAINT `scaleadvisors_ibfk_3` FOREIGN KEY (`insertedby`) REFERENCES `users` (`userid`) ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE `scalefaq`
  ADD CONSTRAINT `scalefaq_ibfk_1` FOREIGN KEY (`insertedby`) REFERENCES `users` (`userid`) ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE `scaleforms`
  ADD CONSTRAINT `scaleforms_ibfk_1` FOREIGN KEY (`insertedby`) REFERENCES `users` (`insertedby`) ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE `scalerequirements`
  ADD CONSTRAINT `scalerequirements_ibfk_1` FOREIGN KEY (`insertedby`) REFERENCES `users` (`userid`) ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE `studentscalereqs`
  ADD CONSTRAINT `studentscalereqs_ibfk_1` FOREIGN KEY (`activitystudentid`) REFERENCES `activitystudents` (`activitystudentid`) ON UPDATE CASCADE,
  ADD CONSTRAINT `studentscalereqs_ibfk_2` FOREIGN KEY (`scalerequirementid`) REFERENCES `scalerequirements` (`scalerequirementid`) ON UPDATE CASCADE,
  ADD CONSTRAINT `studentscalereqs_ibfk_3` FOREIGN KEY (`scaleadvisorid`) REFERENCES `scaleadvisors` (`scaleadvisorid`) ON UPDATE CASCADE,
  ADD CONSTRAINT `studentscalereqs_ibfk_4` FOREIGN KEY (`insertedby`) REFERENCES `users` (`userid`) ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE `submissions`
  ADD CONSTRAINT `submissions_ibfk_1` FOREIGN KEY (`studentid`) REFERENCES `students` (`studentid`) ON UPDATE CASCADE,
  ADD CONSTRAINT `submissions_ibfk_2` FOREIGN KEY (`activityid`) REFERENCES `activities` (`activityid`) ON UPDATE CASCADE,
  ADD CONSTRAINT `submissions_ibfk_3` FOREIGN KEY (`insertedby`) REFERENCES `users` (`userid`) ON DELETE SET NULL ON UPDATE CASCADE;
  
--
-- <Data Setting> --------------------------------------------------------
--

-- Dumping data for table `campuses`
--
INSERT INTO `campuses` (`campusid`, `campusname`, `shortname`, `domain`, `insertedby`, `insertedon`) VALUES
(1, 'Main Campus', 'MC', 'pshs.edu.ph', NULL, '2024-05-06 07:52:57'),
(2, 'Southern Mindanao Campus', 'SMC', 'smc.pshs.edu.ph', NULL, '2024-05-06 08:37:05'),
(3, 'Western Visayas Campus', 'WVC', 'wvc.pshs.edu.ph', NULL, '2024-05-06 08:37:05'),
(4, 'Eastern Visayas Campus', 'EVC', 'evc.pshs.edu.ph', NULL, '2024-05-06 08:37:05'),
(5, 'Cagayan Valley Campus', 'CVC', 'cvc.pshs.edu.ph', NULL, '2024-05-06 08:37:05'),
(6, 'Central Mindanao Campus', 'CMC', 'cmc.pshs.edu.ph', NULL, '2024-05-06 08:37:05'),
(7, 'Bicol Region Campus', 'BRC', 'brc.pshs.edu.ph', NULL, '2024-05-06 08:37:05'),
(8, 'Ilocos Region Campus', 'IRC', 'irc.pshs.edu.ph', NULL, '2024-05-06 08:37:05'),
(9, 'Central Visayas Campus', 'CVisC', 'cvisc.pshs.edu.ph', NULL, '2024-05-06 08:37:05'),
(10, 'Cordillera Autonomous Region Campus', 'CARC', 'carc.pshs.edu.ph', NULL, '2024-05-06 08:37:05'),
(11, 'Central Luzon Campus', 'CLC', 'clc.pshs.edu.ph', NULL, '2024-05-06 08:37:05'),
(12, 'SOCCSKSARGEN Region Campus', 'SRC', 'src.pshs.edu.ph', NULL, '2024-05-06 08:37:05'),
(13, 'CARAGA Region Campus', 'CRC', 'crc.pshs.edu.ph', NULL, '2024-05-06 08:37:05'),
(14, 'CALABARZON Region Campus', 'CALABARZONRC', 'cbzrc.pshs.edu.ph', NULL, '2024-05-06 08:37:05'),
(15, 'MIMAROPA Region Campus', 'MRC', 'mrc.pshs.edu.ph', NULL, '2024-05-06 08:37:05'),
(16, 'Zamboanga Peninsula Region Campus', 'ZRC', 'zrc,pshs.edu.ph', NULL, '2024-05-06 08:37:05');

-- Dumping data for table `extensions`
--
INSERT INTO `extensions` (`extensionid`, `extension`, `ordinal`, `insertedby`, `insertedon`) VALUES
('I', 'I', 120, NULL, '2024-05-06 09:05:35'),
('II', 'II', 20, NULL, '2024-05-06 09:05:35'),
('III', 'III', 30, NULL, '2024-05-06 09:05:35'),
('IV', 'IV', 40, NULL, '2024-05-06 09:05:35'),
('IX', 'IX', 90, NULL, '2024-05-06 09:05:35'),
('Jr', 'Jr', 10, NULL, '2024-05-06 09:05:35'),
('Sr', 'Sr', 110, NULL, '2024-05-06 09:05:35'),
('V', 'V', 50, NULL, '2024-05-06 09:05:35'),
('VI', 'VI', 60, NULL, '2024-05-06 09:05:35'),
('VII', 'VII', 70, NULL, '2024-05-06 09:05:35'),
('VIII', 'VIII', 80, NULL, '2024-05-06 09:05:35'),
('X', 'X', 100, NULL, '2024-05-06 09:05:35');

-- Data dumping for table "users"
--
INSERT INTO `users` (`uuid`, `username`, `passwd`, `insertedby`) VALUES
	(0x11ef0f900e26472ca85b98af65a52331, 'admin', '$2y$10$gFjbslbqbQoz1dtqDVjX/.pRJSIPXCRk9L5loTZ9dk7eo/gLCl5kO', 1),
	(0x2b883d185e52441c9c4a44c3dcbdfdd4, 'coordinator', 'scaleCoordinator', 1),
    (0x59550962e47745b0a8b11d7da26817f4, 'bigchungus', 'scaleStudent1', 1);

INSERT INTO `persons` (`familyname`, `givenname`, `middlename`, `fullname`, `livedname`, `userid`, `insertedby`) VALUES
	('Ordinator', 'Conner', 'Orpheus', 'Connor Orpheus Ordinator', 'Connor', 2, 1),
    ('Chungus', 'Ben Ivan', 'Gaea', 'Ben Ivan Gaea Chungus', 'Ben', 3, 1);

INSERT INTO `employees` (`idnumber`, `userid`, `insertedby`) VALUES
	('384312297873', 2, 1);
    
INSERT INTO `scalerequirements` (`description`, `shortname`) VALUES
	('Service', 'S'),
    ('Creativity', 'C'),
    ('Action', 'A'),
    ('Leadership', 'L'),
    ('Increased awareness of their own strengths and areas for growth', 'LO1'),
    ('Undertaken new challenges', 'LO2'),
    ('Introduced and managed activities', 'LO3'),
    ('Contributed actively in group activities', 'LO4'),
    ('Demonstrated perseverance and commitment in their activities', 'LO5'),
    ('Engaged with issues of global importance', 'LO6'),
    ('Reflected on the ethical consequence of their actions', 'LO7'),
    ('Developed new skills', 'LO8');
    
INSERT INTO `coordinators` (`employeeid`, `acadyear`, `insertedby`) VALUES
	(1, 2025, 1);

INSERT INTO `scalefaq` (`question`, `questioncategory`, `answer`, `insertedby`, `insertedon`) VALUES
	('How do I join a SCALE activity?', 'Processes', 'Once you find the scale activity you wish to join, an apply button will appear at the bottom of the activity information. Pressing it will send a request to the adult supervisor of the activity who will approve you joining the activity. Afterwards, an alert will be sent to the SCALE Coordinators and your SCALE advisor notiying them that you joined a new activity. After their approval, you will now be registered as part of the activity.', 1, '2024-09-03 10:52:55'),
	('What do I do after finishing the activity?', 'Processes', 'After finishing an activity, you need to submit two things: activity documentation and a reflection. For the activity documentation, you can submit anything (photos, videos, certificates, etc.) as long as it’s accepted by your activity supervisor. For the reflection paper, you need to reflect on your experiences while performing the activity. A set of guide questions are provided to help.', 1, '2024-09-03 10:52:55'),
	('What counts as a SCALE activity?', 'SCALEability', 'Ask your ASA', 1, '2024-09-03 10:52:55'),
	('What is a SCALE journal?', 'Processes', 'How should I know? I`m b2025.\r\n', 1, '2024-09-03 10:52:55'),
	('Can I swim for my SCALE action?', 'SCALEability', 'Only if you don\'t already know how to.', 1, '2024-09-03 14:18:59'),
	('This should go to the right place', 'Processes', 'in processes', 1, '2024-09-03 14:19:32'),
	('New cat yo', 'Processes', 'Oh look a cat. We changed the cat!', 1, '2024-09-03 22:05:54'),
	('What am I doing', 'Processes', 'idk tbh', 1, '2024-09-04 15:34:40'),
	('Dogs are better', 'SCALEability', 'L opinion + unbased', 1, '2024-09-04 16:03:49'),
	('New cat 2', 'Meow', 'Another car', 1, '2024-09-04 16:05:03');

INSERT INTO `scaleforms` (`formtitle`, `formdescription`, `versionnumber`, `isactive`, `insertedby`, `insertedon`) VALUES
	('SCALE Personal Information Sheet', 'This form will satisfy Requirement 3.5.3.1 Self-review at the beginning of their SCALE experience and set personal goals for what they hope to achieve thru their SCALE Program.', 'PSHS-00-F-DSA-11-Ver02-Rev0-02/01/20', 1, NULL, '2024-05-08 16:21:02'),
	('SCALE Program Proposal Form', 'This form will satisfy Requirement 3.5.3.2 Plan, do and reflect (plan activities, carry them out and reflect on what they have learned).', 'PSHS-00-F-DSA-12-Ver02-Rev0-02/01/20', 1, NULL, '2024-05-08 16:21:02'),
	('SCALE Individual Activity Plan', 'This form will satisfy Requirement 3.5.3.2 Plan, do and reflect (plan activities, carry them out and reflect on what they have learned). Additionally, it may satisfy Requirement 3.5.3.3 and Requirement 3.5.3.4 as defined in Section 3.4.4 At least one major project, involving collaboration and the integration of at least two of creativity, leadership, action and service, is required.', 'PSHS-00-F-DSA-13-Ver02-Rev0-02/01/20', 1, NULL, '2024-05-08 16:21:02'),
	('SCALE Individual Program Report', 'This form allows for students and SCALE Advisers to review the progress of activities performed and to report completion.', ' PSHS-00-F-DSA-14-Ver02-Rev0-02/01/20', 1, NULL, '2024-05-08 16:21:02'),
	('SCALE Advisers Quarterly Report', 'This form is provided to monitor progress of all students assigned to a SCALE Adviser', ' PSHS-00-F-DSA-15-Ver02-Rev0-02/01/20', 1, NULL, '2024-05-08 16:21:02'),
	('SCALE Advisers Endorsement Form', 'This form allows SCALE Advisers to recommend students for SCALE Program completion to the SCALE Coordinator', 'PSHS-00-F-DSA-16-Ver02-Rev0-02/01/20', 1, NULL, '2024-05-08 16:21:02'),
	('SCALE Coordinators Program Report', 'This form allows SCALE Coordinators to recommend students for SCALE Program completion to the Division Chief', ' PSHS-00-F-DSA-17-Ver02-Rev0-02/01/20', 1, NULL, '2024-05-08 16:21:02'),
	('SCALE Coordinators Quarterly Report', 'This form is provided for SCALE Coordinators to monitor the progress of all students in their campus', 'PSHS-00-F-DSA-18-Ver02-Rev0-02/01/20', 1, NULL, '2024-05-08 16:21:02');

-- <Permissions> Needs to be manually run I think

-- GRANT ALL ON scalesite.* TO 'admin'@'localhost' IDENTIFIED BY 'scaleable';

COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
